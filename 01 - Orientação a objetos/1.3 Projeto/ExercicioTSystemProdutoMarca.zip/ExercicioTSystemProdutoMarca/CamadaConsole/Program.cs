﻿using CamadaConsole;

class Program
{
    public static List<Marca> marcasDados = new List<Marca>();
    public static List<Produto> produtosDados = new List<Produto>();

    static void Main(string[] args)
    {
        ServicosProduto svc = new ServicosProduto(new Desconto10PorCento());
        svc.CalcularDescontoProduto("Samsung");

        ServicosMarca svcMarca = new ServicosMarca();
        svcMarca.Inserir(new Marca("Apple"));
        svcMarca.Inserir(new Marca("Samsung"));
        svcMarca.Inserir(new Marca("LG"));


    }
}




















class Converter
{
    public static int ConverterParaInteiro(string valor)
    {
        try
        {
            int inteiro = int.Parse(valor);
            return inteiro;
        }
        catch (Exception ex)
        {
            return 0;
        }
    }
}



class Teste
{
    public int x;
    public static int y;

    public static void Fazer()
    {
    }
}
 


