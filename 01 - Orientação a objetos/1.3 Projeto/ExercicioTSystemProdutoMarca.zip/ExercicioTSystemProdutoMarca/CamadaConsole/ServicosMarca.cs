﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace CamadaConsole
{
    public class ServicosMarca : IServicosMarca
    {
        public bool Atualizar(string marcaAntiga, string marcaNova)
        {
            if (!Validation.ValidateNomeMarca(marcaNova))
            {
                return false;
            }
            marcaNova = marcaNova.ToUpper();
            bool atualizou = false;
            for (int i = 0; i < Program.marcasDados.Count; i++)
            {
                if (Program.marcasDados[i].getNome() == marcaAntiga)
                {
                    if (this.EhUnica(marcaNova))
                    {
                        Program.marcasDados[i].setNome(marcaNova);
                        atualizou = true;
                    }
                    break;
                }
            }
            return atualizou;
        }

        public bool EhUnica(string marca)
        {
            marca = marca.ToUpper();
            for (int i = 0; i < Program.marcasDados.Count; i++)
            {
                if (Program.marcasDados[i].getNome() == marca)
                {
                    return true;
                }
            }
            return false;
        }

        public bool Excluir(string marca)
        {
            marca = marca.ToUpper();
            //Nao permite excluir uma marca que está vinculada a um produto
            for (int i = 0; i < Program.produtosDados.Count; i++)
            {
                if (Program.produtosDados[i].getMarca().getNome() == marca)
                {
                    return false;
                }
            }

            bool excluiu = false;
            //Verifica se encontrou a marca a ser excluida
            for (int i = 0; i < Program.marcasDados.Count; i++)
            {
                if (Program.marcasDados[i].getNome() == marca)
                {
                    Program.marcasDados.RemoveAt(i);
                    excluiu = true;
                    break;
                }
            }
            return excluiu;
        }

        public bool Inserir(Marca m)
        {
            if (this.EhUnica(m.getNome()))
            {
                return false;
            }

            if (!Validation.ValidateNomeMarca(m.getNome()))
            {
                return false;
            }
            m.setNome(m.getNome().ToUpper());
            Program.marcasDados.Add(m);
            return true;
        }

        public List<Marca> Listar()
        {
            return Program.marcasDados;
        }
    }
}
