﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CamadaConsole
{
    public class ServicosProduto : IServicosProduto
    {
        private IDesconto _desconto;
        public ServicosProduto(IDesconto desconto)
        {
            this._desconto = desconto;
        }

        public bool Atualizar(string produtoAntigo, Produto produtoNovo)
        {
            bool atualizou = false;
            for (int i = 0; i < Program.produtosDados.Count; i++)
            {
                if (Program.produtosDados[i].getNome() == produtoAntigo)
                {
                    if (this.EhUnica(produtoNovo.getNome()))
                    {
                        Program.produtosDados[i] = produtoNovo;
                        atualizou = true;
                    }
                    break;
                }
            }
            return atualizou;
        }

        public double CalcularDescontoProduto(string nome)
        {
            for (int i = 0; i < Program.produtosDados.Count; i++)
            {
                if (Program.produtosDados[i].getNome() == nome)
                {
                    double preco = Program.produtosDados[i].getPreco();
                    return _desconto.CalcularDesconto(preco);
                }
            }
            return 0;
        }

        public bool EhUnica(string Produto)
        {
            for (int i = 0; i < Program.produtosDados.Count; i++)
            {
                if (Program.produtosDados[i].getNome() == Produto)
                {
                    return true;
                }
            }
            return false;
        }


        public bool Excluir(string Produto)
        {
            bool excluiu = false;
            for (int i = 0; i < Program.produtosDados.Count; i++)
            {
                if (Program.produtosDados[i].getNome() == Produto)
                {
                    Program.produtosDados.RemoveAt(i);
                    excluiu = true;
                    break;
                }
            }
            return excluiu;
        }

        public bool Inserir(Produto m)
        {
            if (this.EhUnica(m.getNome()))
            {
                return false;
            }
            Program.produtosDados.Add(m);
            return true;
        }

        public List<Produto> Listar()
        {
            return Program.produtosDados;
        }

        public List<Produto> Listar(string pesquisa)
        {
            throw new NotImplementedException();
        }
    }
}
