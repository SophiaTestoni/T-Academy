﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CamadaConsole
{
    public class Validation
    {
        public static bool ValidateNomeMarca(string valor)
        {
            if (valor == "" || valor.Length < 3 || valor.Length > 40)
            {
                return false;
            }
            return true;
        }
    }
}
