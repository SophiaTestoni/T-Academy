﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CamadaConsole
{
    public interface IServicosProduto
    {
        bool Inserir(Produto m);
        bool Atualizar(string produtoAntigo, Produto produtoNovo);
        bool Excluir(string marca);
        List<Produto> Listar();
        List<Produto> Listar(string pesquisa);
        bool EhUnica(string marca);
        double CalcularDescontoProduto(string nome);
    }
}
