﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace CamadaConsole
{
    public class Produto
    {
        private string nome;
        private double preco;
        private Marca marca;

        public Produto(string nome, double preco, Marca marca)
        {
            this.nome = nome;
            this.preco = preco;
            this.marca = marca;
        }

        public void setMarca(Marca m)
        {
            this.marca = m;
        }

        public Marca getMarca()
        {
            return this.marca;
        }

        public void setNome(string nome)
        {
            this.nome = nome;
        }

        public string getNome()
        {
            return this.nome;
        }

        public void setPreco(double preco)
        {
            this.preco = preco;
        }

        public double getPreco()
        {
            return this.preco;
        }
    }
}
